<template>
  <div class="orderfood">

    <NProgress v-if="loadingflag" />
    <!--    tab切换-->
    <div class="tabListBox">
      <div
        v-for="item in cake == 88 ? tabList.filter(item => item.active == 2) : flag == 0 ? tabList : flag == 2 ? tabList.filter(item => item.active != 3 && item.active != 2) : tabList.filter(item => item.active != 3)"
        :key="item.active" :style="{ backgroundImage: item.active == active ? 'url(' + item.back + ')' : '' }"
        class="tabItem" @click="changeType(item.active)"
        :class="{ tabItem2: item.active == active, tabItem3: cake ? cake != 2 : false, tabItem4: item.active == active && cake != 1 || types == 1, }"
        v-if="item.isShow">
        <div>{{ item.title }}</div>
        <div class="tabIcon" v-if="item.active == active">
          <img class="img" src="../../assets/zhichong/xuanz.png" alt="">
        </div>
      </div>
    </div>
    <!--    自助点餐-->
    <div class="leftwrap" v-if="active == 3 && flag == 0">

      <img src="../../assets/newico/tp.png" alt="" style="width: 100%;">
      <div style="margin-top: 5px;padding: 0 10px;" @click="toNexts()">
        <van-notice-bar :text="gonggao" left-icon="volume-o" />
      </div>
      <div class="pd0">
        <div class="banner1" v-for="(item, index) in imgurlbox" :key="item.id" v-if="item.id != 25"
          @click="goindex(index + 1, index <= 2 || index == 6 ? 1 : 2)">
          <img class="img" :src="item.img" alt="">
        </div>
      </div>
    </div>
    <!--    电子券-->
    <div class="rightwrap" v-if="active == 1">


      <ElectronicCoupon></ElectronicCoupon>
    </div>

    <div class="brandList" v-if="active == 2 && (flag != 2 || cake == 88)">
      <div v-for="item in brandList" :key="item.id" class="brandItem" @click="todetail(item.id)">
        <img class="img" :src="item.img" alt="">
      </div>
    </div>

    <!-- 随心兑 -->


    <div v-if="active == 4" class="exchange-wrap">

      <!-- 1. 顶部搜索框 -->
      <div class="search-header">
        <div class="search-box">
          <van-icon name="search" class="search-icon" />
          <input type="text" v-model="searchKeyword" placeholder="输入门店名称" class="search-input"
            @keyup.enter="onSearch" />
        </div>
      </div>

      <!-- 2. 品牌区域 (相对定位，用于包裹横滑和下拉面板) -->
      <div class="brand-section">
        <!-- 2.1 横滑区域 -->
        <div class="brand-scroll-wrap">
          <!-- 品牌列表 -->
          <div class="brand-item" v-for="brand in exchangeBrands" :key="brand.id" :id="'brand-' + brand.id"
            :class="{ active: currentBrandId === brand.id }" @click="selectBrand(brand, brand.id)">
            <img :src="brand.logo || brand.img" alt="" class="brand-logo">
            <div class="brand-name">{{ brand.name || brand.title }}</div>
          </div>

          <!-- 右侧固定的“全部”按钮 -->
          <div class="brand-all-btn" :class="{ active: showAllBrands || currentBrandId === 0 }"
            @click="toggleAllBrands">
            全部 <van-icon :name="showAllBrands ? 'arrow-up' : 'arrow-down'" />
          </div>
        </div>

        <!-- 2.2 点击“全部”后在当前区域展开的面板 -->
        <div class="all-brand-panel" v-show="showAllBrands">
          <div class="all-brand-grid">
            <div class="grid-brand" v-for="brand in exchangeBrands" :key="'all-' + brand.id"
              @click="selectBrand(brand, brand.id)">
              <img :src="brand.logo || brand.img" alt="">
              <div class="grid-brand-name">{{ brand.name || brand.title }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 3. 下方的门店/商品列表 -->
      <!-- 3. 下方的门店/商品列表 -->
      <div class="shop-list">
        <!-- 状态 1：首次进入或切换品牌时的加载中（覆盖全屏） -->
        <div v-if="isShopLoading && !isLoadMore" style="text-align: center; color: #999; padding: 40px 0;">
          <van-loading size="24" vertical>正在加载...</van-loading>
        </div>

        <!-- 状态 2：加载完毕且没有数据 -->
        <div v-else-if="!isShopLoading && exchangeShopList.length === 0"
          style="text-align: center; font-size: 12px; color: #999; padding: 40px 0;">

          <p>没有找到相关门店</p>
        </div>

        <!-- 状态 3：有数据 -->
        <div v-else class="shop-card" v-for="(item, index) in exchangeShopList" :key="item.id || index">
          <div class="shop-logo">

            <img :src="logoImg" alt="">
          </div>
          <div class="shop-info">
            <div class="shop-title-row">
              <div class="shop-name">{{ item.name }}</div>
              <div class="shop-distance" v-if="item.distance != null">
                距您 {{ item.distance >= 1000 ? (item.distance / 1000).toFixed(2) + 'km' : item.distance + 'm' }}
              </div>
            </div>
            <div class="shop-address"><van-icon name="location-o"  /> {{ item.address }}</div>
            <div class="shop-tags">
              <span class="tag">到店兑换</span>
            </div>
            <div style="text-align: right;" @click="goExchange(item)"><span class="shop-btn">去兑换</span></div>
          </div>

        </div>

        <!-- 状态 4：底部上拉加载更多的提示 -->
        <div v-if="isLoadMore" style="text-align: center; color: #999; padding: 10px 0; font-size: 12px;">
          <van-loading size="16"
            style="display: inline-block; vertical-align: middle; margin-right: 4px;">加载中...</van-loading>
        </div>
      </div>

    </div>
    <!-- 随心兑换 -->


  </div>
</template>

<script>
import { getWxLocation } from '@/utils/wxLocation'
import { getBannerList, getBannerLists, getIsShowOder, sxfcard, brandnew, DangaoStore } from '@/api/service'
import ElectronicCoupon from "@/components/select/ElectronicCoupon.vue";
import { getBrandDirect } from "@/api/brand";
export default {
  components: { ElectronicCoupon },
  data() {
    return {
      logoImg: '',
      sxfcardfag: '',
      shopPageNo: 1,
      isShopLoading: false, isLoadMore: false, isFetching: false,
      showAd: true,
      gonggao: '尊敬的悦享聚汇用户，您好，感谢您一直以来的信任与支持。为给您提供更稳定的服务，现有一项重要安排需向您通知。近期，由于麦当劳、瑞幸、库迪、塔斯汀等品牌供应链体系波动导致我平台部分订单履约稳定性受到一定影响。为从根本上解决这一问题，提升整体服务质量，我们决定对以上品牌系统进行一次集中维护与优化。维护时间:2025年3月6日12:00，维护期间，以上点餐品牌订单成功率会受到一定程度影响，维护期间出餐成功率预计，麦当劳(50%)瑞幸(80%)、库迪(80%)、塔斯汀(50%)，具体表现，部分订单可能出现延迟、失败退款等需要人工处理，我们力争在3月15日前完成全部优化工作，数据恢复后我们将第一时间通知。因本次维护给您带来的不便，我们深表歉意，也衷心感谢您的理解与支持。',
      active: 1,
      imgurlbox: [],
      loadingflag: true,
      cake: 0,
      types: 0,
      tabList: [
        {
          title: "电子券",
          active: 1,
          back: require("../../assets/zhichong/yb.png")
        },
        {
          title: "随心兑",
          active: 4,
          back: require("../../assets/zhichong/yb.png")
        },

        {
          title: "饮品直冲",
          active: 2,
          back: require("../../assets/zhichong/zj.png")
        },
        {
          title: "自助点餐",
          active: 3,
          back: require("../../assets/zhichong/zb.png")
        },
      ],
      pageno: 1,
      brandList: [],
      isScroll: false,
      flag: 0,
      signal: 0,

      showAllBrands: false,
      searchKeyword: "",       // 搜索关键词
      currentBrandId: 0,       // 当前选中的品牌ID，0代表全部
      showAllBrands: false,    // 是否展示全屏品牌面板
      exchangeBrands: [        // 临时模拟的品牌数据，你需要换成接口获取的
      ],
      exchangeShopList: [      // 临时模拟的下方门店数据

      ],

    };
  },
  methods: {
    // 计算两点距离（单位：米）
    getDistance(lat1, lng1, lat2, lng2) {
      if (!lat1 || !lng1 || !lat2 || !lng2) return null;
      const rad = Math.PI / 180;
      const R = 6371000; // 地球半径
      const dLat = (lat2 - lat1) * rad;
      const dLng = (lng2 - lng1) * rad;
      const a = Math.sin(dLat / 2) ** 2 +
        Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) ** 2;
      return Math.round(2 * R * Math.asin(Math.sqrt(a))); // 返回整数米
    },
    scrollToActiveBrand(brandId) {
      if (!brandId) return;
      this.$nextTick(() => {
        const container = document.querySelector('.brand-scroll-wrap');
        const target = document.getElementById('brand-' + brandId);

        if (container && target) {
          // 计算目标元素相对于滚动容器的偏移量
          const offsetLeft = target.offsetLeft;
          // 让容器的滚动条平滑滚动到目标位置
          // 为了看起来居中，稍微减去一点偏移（比如减去 100px）
          container.scrollTo({
            left: offsetLeft - 100,
            behavior: 'smooth' // 平滑滚动
          });
        }
      });
    },
    brandnews() {
      return brandnew().then(res => {
        if (res.code == 200 && res.data) {
          this.exchangeBrands = res.data.map(item => ({
            id: item.brand_id,
            name: item.name,
            logo: item.logo
          }));

          // 默认Logo
          if (this.exchangeBrands.length > 0) {
            this.logoImg = this.exchangeBrands[0].logo;
          }

          // 只有当前在随心兑页面，才去请求门店列表
          if (this.active == 4) {
            const urlBrandId = this.$route.query.brandId;
            let requestBrandId = '';

            if (urlBrandId) {
              // 有指定的 brandId
              requestBrandId = urlBrandId;
              this.currentBrandId = urlBrandId;
              const currentBrandObj = this.exchangeBrands.find(b => b.id == urlBrandId);
              if (currentBrandObj) {
                this.logoImg = currentBrandObj.logo;
              }
              this.scrollToActiveBrand(urlBrandId);
            } else if (this.exchangeBrands.length > 0) {
              // 没指定 brandId，默认选中第一个
              requestBrandId = this.exchangeBrands[0].id;
              this.currentBrandId = requestBrandId;
            }

            // 发请求（带上经纬度逻辑）
            getWxLocation()
              .then(loc => {
                // 把城市名和经纬度写进 sessionStorage，和 City.vue 保持一致
                if (loc.city) sessionStorage.setItem('cityName', loc.city)
                sessionStorage.setItem('longitude', loc.longitude)
                sessionStorage.setItem('latitude', loc.latitude)
                this.fetchExchangeShopList(requestBrandId, this.searchKeyword, false, loc.latitude, loc.longitude)
              })
              .catch(() => {
                // 定位失败（非微信/用户拒绝/签名失败）都走这里，降级为不带经纬度
                this.fetchExchangeShopList(requestBrandId, this.searchKeyword)
              })
          }
        }
      });
    },
    updateTabShow() {
      this.tabList.forEach(item => {
        if (item.active == 4) {
          item.isShow = this.sxfcardfag == 1
        } else if (this.cake == 88) {
          item.isShow = item.active == 2
        } else if (item.active == 1 || item.active == 2) {
          item.isShow = this.cake != 2
        } else {
          item.isShow = this.cake != 1 || this.types == 1
        }
      })
    },

    sxfcards() {
      sxfcard()
        .then(res => {
          // 1. 给标记赋值
          this.sxfcardfag = (res.code == 200 && res.data) ? res.data.sxf : ''

          // 2. 🚨 核心：必须在这里重新调用，才能让 tab 显示出来
          this.updateTabShow()

          // 3. 如果当前正停留在随心兑，但查出来没权限（!=1），则强制切回电子券
          if (this.active == 4 && this.sxfcardfag != 1) {
            this.active = 1
            this.$router.replace({ path: "/orderfood", query: { active: 1 } })
          }
        })
        .catch(() => {
          this.sxfcardfag = ''
          this.updateTabShow()
          if (this.active == 4) {
            this.active = 1
            this.$router.replace({ path: "/orderfood", query: { active: 1 } })
          }
        })
    },
    toggleAllBrands() {
      this.showAllBrands = !this.showAllBrands;
    },
    selectBrand(val, id) {
      console.log(val.logo)
      this.logoImg = val.logo
      this.currentBrandId = id;
      this.showAllBrands = false; // 选完品牌后收起面板
      this.searchKeyword = "";
      window.scrollTo(0, 0);
      this.isScroll = false;
      const lat = sessionStorage.getItem('latitude') || '';
      const lng = sessionStorage.getItem('longitude') || '';
      this.fetchExchangeShopList(id, this.searchKeyword, false, lat, lng);
      // this.fetchExchangeShopList(id, this.searchKeyword);
    },


    goExchange(item) {
      this.$router.push({
        path: '/GetpayqrCode', // 你的付款码页面路由
        query: {
          brandId: item.id || this.currentBrandId, // 如果有品牌ID就用，没有就用当前选中的
          shopId: item.shopId,
          brandName: item.brandName || '好利来',        // 品牌名称
          shopName: item.name,                         // 门店名称
          address: item.address,                       // 门店地址
          distance: item.distance,                     // 距离
          logo: this.logoImg                           // 🚨 把当前选中的品牌 LOGO 传过去
        }
      })
    },


    // 搜索逻辑
    onSearch() {
      // console.log("正在搜索：", this.searchKeyword);
      // this.fetchExchangeShopList(this.currentBrandId, this.searchKeyword);
      const lat = sessionStorage.getItem('latitude') || '';
      const lng = sessionStorage.getItem('longitude') || '';
      this.fetchExchangeShopList(this.currentBrandId, this.searchKeyword, false, lat, lng);

    },

    // 获取下方门店列表
    fetchExchangeShopList(brandId = '', keyword = '', append = false, lat = '', lng = '') {
      // 🚨 核心拦截：如果当前正在发请求，直接 return，不执行下面的逻辑
      if (this.isFetching) return;
      this.isFetching = true;

      if (!append) {
        this.exchangeShopList = [];
        this.shopPageNo = 1;
        this.isScroll = false;
        this.isShopLoading = true;
      } else {
        this.isLoadMore = true;
      }

      const params = {
        pageNo: this.shopPageNo,
        pageSize: 10,
        brandId: brandId || '',
        shopName: keyword || '',
        latitude: lat || '',
        longitude: lng || '',
        city: sessionStorage.getItem('cityName') || '',
      };

      DangaoStore(params).then(res => {
        if (res.code == 200 && res.data) {
          let rows = res.data.rows || [];

          // 🚨 核心修改：拿到当前缓存的用户经纬度，遍历计算距离
          const userLat = sessionStorage.getItem('latitude');
          const userLng = sessionStorage.getItem('longitude');

          if (userLat && userLng) {
            rows.forEach(item => {
              // 如果后端没给，并且门店有经纬度，前端自己算
              if (item.distance === null || item.distance === undefined) {
                if (item.lat && item.lng) {
                  item.distance = this.getDistance(
                    Number(userLat), Number(userLng),
                    Number(item.lat), Number(item.lng)
                  );
                }
              }
            });
          }

          if (rows.length < 10) {
            this.isScroll = true; // 无更多数据
          }

          if (append) {
            this.exchangeShopList = this.exchangeShopList.concat(rows);
          } else {
            this.exchangeShopList = rows;
          }
        } else {
          if (!append) this.exchangeShopList = [];
          this.isScroll = true;
        }
      }).catch(() => {
        if (!append) this.exchangeShopList = [];
        this.$toast('获取门店列表失败');
      }).finally(() => {
        this.isFetching = false;
        this.isShopLoading = false;
        this.isLoadMore = false;
      });
    },
    // 关闭广告
    closeImg() { this.showAd = false; },
    closeAd() {
      this.showAd = false;

    },

    // 点击广告图片
    toNexts() {
      window.location.href = 'http://yxfmm.bjyxfl.com/imgs/ad2.png';
    },
    getIsShowOder() {
      getIsShowOder().then(res => {
        if (res.code == 200) {
          this.flag = res.data.flag
          this.signal = res.data.signal
        }
      })
    },
    todetail(id) {
      this.$router.push({ path: "/directCharge", query: { id } })
    },
    changeType(e) {
      this.active = e
      if (this.active == 2) {
        this.brandList = []
        this.pageno = 1
        this.getBrandDirect()
      } else if (this.active == 3) {
        this.showAd = true
        this.getlistpics()
      }
      this.$router.replace({ path: "/orderfood", query: { active: e } })
    },
    getlistpic() {
      getBannerList({
        flag: '1',
        // type:'mdl'
      }).then(res => {
        this.loadingflag = false
        // console.log(res);
        if (res.code == 200) {
          this.imgurlbox = res.data.list
          // console.log(this.imgurlbox);
        }

      })
    },
    getlistpics() {
      getBannerLists({
        flag: '1',
        // type:'mdl'
      }).then(res => {
        this.loadingflag = false
        console.log(res);
        if (res.code == 200) {
          this.imgurlbox = res.data.list

        }

      })
    },
    goindex(num1, num2) {
      // if(num1==4){
      //   this.$toast("正在建设中...,敬请期待")
      //   return
      // }
      this.$router.push({ path: "/select", query: { num1: num1, num2: num2 } })
    },
    getBrandDirect(pageno = this.pageno) {
      getBrandDirect({
        pageno,
        pagesize: 10
      }).then(res => {
        this.loadingflag = false
        if (res.code == 200) {
          if (res.data.length == 0) {
            this.isScroll = true
            return
          }
          res.data.forEach(item => {
            this.brandList.push(item)
          })

        }
      })
    },
    //滚动条事件
    handleScroll(e) {
      let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
      let scrollHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
      let clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
      // if (Math.ceil(scrollTop + clientHeight) >= scrollHeight) {
      //   this.onMost()
      // }

      if (Math.ceil(scrollTop + clientHeight) >= scrollHeight - 100) {
        this.onMost()
      }



    },
    onMost() {
      // 🚨 修复核心：只要正在发请求，或者已经到底了，直接 return 阻断，什么都不做！
      if (this.isFetching || this.isScroll) return;

      if (this.active == 2) {
        this.pageno++
        this.getBrandDirect(this.pageno)
      } else if (this.active == 4) {
        // 列表为空时也不允许加载下一页
        if (this.exchangeShopList.length === 0) return;

        this.shopPageNo++
        this.fetchExchangeShopList(this.currentBrandId, this.searchKeyword, true);
      }
    },

  },
  created() {
    this.loadingflag = false;
    this.getIsShowOder()
    if (sessionStorage.getItem("cake")) {
      this.cake = sessionStorage.getItem("cake")
    }
    if (sessionStorage.getItem("types")) {
      this.types = sessionStorage.getItem("types")
    }
    this.active = this.$route.query.active || 1
    if (this.cake == 2) {
      this.active = 3
    }

    if (this.cake == 88) {
      this.active = 2
    }


    this.updateTabShow()
  },
  watch: {
    '$route'(to, from) {
      if (to.path === '/orderfood' && to.query.active == 4 && to.query.brandId) {
        this.active = 4;
        this.currentBrandId = to.query.brandId;

        const currentBrandObj = this.exchangeBrands.find(b => b.id == to.query.brandId);
        if (currentBrandObj) {
          this.logoImg = currentBrandObj.logo;
        }

        this.fetchExchangeShopList(to.query.brandId, this.searchKeyword);

        // 🚨 调用滚动方法
        this.scrollToActiveBrand(to.query.brandId);
      }
    }
  },
  mounted() {
    this.sxfcards();
    this.brandnews();

    if (this.active == 2) {
      this.getBrandDirect();
    } else if (this.active == 3) {
      this.getlistpics();
    } else if (this.active == 1) {
      setTimeout(() => {
        this.loadingflag = false;
      }, 500);
    } else if (this.active == 4) {
      this.loadingflag = false;

    }
    window.addEventListener('scroll', this.handleScroll);
  },
  beforeDestroy() {
    window.removeEventListener('scroll', this.handleScroll, false);
  },
};
</script>
<style>
.shop-address .van-icon{
  color: #EB6A73;position: relative;top: 2px;font-weight: bold;
}
</style>
<style scoped lang="less">
// 悬浮广告样式 // yishagn以上控制广告



// yishagn以上控制广告
.orderfood {
  min-height: 100vh;
  background: #f0f0f0;
  padding-top: 10px;
  box-sizing: border-box;

}

// .leftwrap {
//   padding: 0px 10px 10px;

//   .banner1 {
//     margin-top: 10px;
//   }
// }
.leftwrap {
  width: 100%;

  .pd0 {
    margin-top: 2px;
    padding: 0px 10px 50px 10px;
    display: flex;
    // gap: 7px;
    justify-content: space-between;
    flex-wrap: wrap;
  }

  .banner1 {
    width: 49%;
    margin-top: 5px;
  }
}

.tabListBox {
  background-image: url("../../assets/zhichong/jbback.png");
  background-size: 100% 100%;
  width: 100%;
  height: 44px;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;

  .tabItem {
    width: 33.3%;
    width: 50%;
    text-align: center;
    background-size: 100% 100%;
    font-size: 14px;
    color: #646166;
    height: 54px;
    line-height: 64px;
  }

  .tabItem2 {
    line-height: 54px;
    font-size: 15px;
    font-weight: bold;
    color: #343434;
  }

  .tabItem3 {
    width: 50%;
  }

  //.tabItem4{
  //  margin: 0 auto;
  //}
  .tabIcon {
    width: 16px;
    margin: auto;
    margin-top: -13px;
  }
}

.brandList {
  display: flex;
  flex-wrap: wrap;
  padding: 10px;
  gap: 10px 2px;
  justify-content: space-between;

  .brandItem {
    width: calc(50% - 2px);
  }
}

// suixindui
/* 随心兑模块样式 */
.exchange-wrap {
  background: #f0f0f0;
  min-height: calc(100vh - 54px);
  position: relative;
  padding-bottom: 20px;
}

/* 顶部搜索 */
.search-header {
  padding: 10px 15px;
  background: #fff;

  .search-box {
    display: flex;
    align-items: center;
    background: #f5f5f5;
    border-radius: 20px;
    padding: 6px 12px;

    .search-icon {
      color: #999;
      font-size: 16px;
      margin-right: 6px;
    }

    .search-input {
      border: none;
      background: transparent;
      flex: 1;
      outline: none;
      font-size: 14px;
    }
  }
}

/* 品牌区域包裹层 */
.brand-section {
  position: relative;
  background: #fff;
}

/* 品牌横滑 */
.brand-scroll-wrap {
  display: flex;
  overflow-x: auto;
  padding: 10px 15px;
  gap: 15px;
  align-items: center;
  border-bottom: 1px solid #eee;
  /* 右侧留出“全部”按钮的空间 */
  padding-right: 60px;

  &::-webkit-scrollbar {
    display: none;
  }

  .brand-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    position: relative;
    background-color: #fff;

    .brand-logo {
      width: 50px;
      height: 50px;
      border-radius: 8px;
      // border: 1px solid #eee;
      object-fit: contain;
      margin-bottom: 5px;
    }

    .brand-name {
      font-size: 12px;
      color: #666;
      text-align: center;
    }

    /* 选中状态 */
    &.active {
      .brand-logo {
        border-color: #F99E9B;
      }

      .brand-name {
        color: #F99E9B;
        font-weight: bold;
      }
    }
  }
}

/* 右侧悬浮的“全部”按钮 */
.brand-all-btn {
  position: absolute;
  right: 0;
  top: 0;
  bottom: 0;
  width: 60px;
  background: linear-gradient(to right, rgba(255, 255, 255, 0.8), #fff 40%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  color: #333;
  z-index: 10;
  border-bottom: 1px solid #eee;
  cursor: pointer;

  .van-icon {
    margin-left: 2px;
    font-size: 12px;
  }

  &.active {
    color: #F99E9B;
    font-weight: bold;
  }
}

/* 在当前页面展开的面板 */
.all-brand-panel {
  position: absolute;
  top: 100%;
  /* 紧贴在横滑条下方 */
  left: 0;
  width: 100%;
  background: #fff;
  z-index: 99;
  padding: 15px;
  box-sizing: border-box;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 0 0 10px 10px;

  .all-brand-grid {
    display: flex;
    flex-wrap: wrap;
    row-gap: 15px;
    max-height: 50vh;
    /* 限制最大高度，超出可滑动 */
    overflow-y: auto;

    .grid-brand {
      width: 20%;
      /* 一行5个 */
      display: flex;
      flex-direction: column;
      align-items: center;

      img {
        width: 45px;
        height: 45px;
        border-radius: 8px;
        border: 1px solid #eee;
        object-fit: contain;
        margin-bottom: 5px;
      }

      .grid-brand-name {
        font-size: 12px;
        color: #333;
        text-align: center;


        width: 100%;
        /* 占满 20% 格子的宽度 */

        box-sizing: border-box;
        /* 让 padding 不影响宽度计算 */
        white-space: nowrap;
        /* 强制不换行 */
        overflow: hidden;
        /* 超出部分隐藏 */
        text-overflow: ellipsis;
        /* 超出部分显示省略号... */


      }
    }
  }
}

/* 底部列表 */
.shop-list {
  padding: 10px;
  /* 如果展开面板很高，可以给列表加个遮罩或让出空间，这里默认不处理 */

  .shop-card {
    background: #fff;
    border-radius: 10px;
    padding: 15px;
    margin-bottom: 10px;
    display: flex;
    align-items: center;

    .shop-logo {
      width: 76px;
      height: 76px;


      margin-right: 12px;

      img {
        border-radius: 8px;
        width: 100%;
        height: 100%;
        object-fit: contain;
      }
    }

    .shop-info {
      flex: 1;

      .shop-title-row {
        display: flex;
        justify-content: space-between;
        align-items: center;

        .shop-name {
          font-size: 14px;
          font-weight: bold;
          color: #333;
        }

        .shop-distance {
          font-size: 12px;
          color: #999;
        }
      }

      .shop-address {
        font-size: 12px;
        color: #666;
        margin-top: 5px;
      }

      .shop-tags {
        margin-top: 2px;

        .tag {
          font-size: 10px;
          color: #F99E9B;
          border: 1px solid #F99E9B;
          padding: 2px 5px;
          border-radius: 4px;
        }
      }
    }

    .shop-btn {
      background: #4FA0F9;
      color: #fff;
      font-size: 12px;
      padding: 4px 12px;
      border-radius: 15px;

    }
  }
}


//suixindui
</style>
