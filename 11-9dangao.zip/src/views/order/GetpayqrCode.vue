<template>
  <div class="pay-code-page">
    <NProgress v-if="loading" />

    <!-- 顶部门店卡片 -->
    <div class="store-card">
      <div class="store-header">
        <div class="store-logo">
          <img :src="brandLogo || require('@/assets/newico/tp.png')" alt="" />
        </div>
        <div class="store-info">
          <div class="row">品牌名称：{{ brandName }}</div>
          <div class="row">门店地址：{{ shopName }}</div>
        </div>
      </div>
      <div class="store-current">
        <div class="current-title">当前门店可用</div>
        <div class="current-address">
          <div class="address-left">
            <span class="title">{{ shopName }}</span>
            <div class="desc"><van-icon name="location-o" /> {{ address }}</div>
          </div>
          <div class="distance" v-if="distance">距离最近 {{ distance }}</div>
        </div>
      </div>
    </div>

    <!-- 提示条 -->
    <div class="notice-bar">
      <van-icon name="volume-o" color="#F99E9B" />
      <span v-if="brandName =='泸溪河' || brandName =='85度c' ">请告知门店使用【HX福利等第三方渠道】扫码收款</span>
      <span v-else>请告知门店使用【悦享福利等第三方渠道】扫码收款</span>
    </div>

    <!-- 付款码核心展示区 -->
    <div class="pay-code-card">
      <div class="card-title">
        <van-icon name="replay" class="icon-refresh" @click="getCode" /> 付款码
      </div>

      <div v-if="payCode" class="code-container">



        <!-- 轻触可查看数字的提示 -->
        <div class="tip-text" @click="showNumberCode">
          <van-icon name="hand-up" /> 轻触可查看数字
        </div>

        <!-- 二维码区域（纯本地 Canvas 绘制，不会出现灰块） -->
        <div class="qrcode-box" @click="showNumberCode">
          <canvas id="qrCanvas" width="160" height="160" style="display: block;"></canvas>
        </div>

        <!-- 底部倒计时 -->
        <div class="countdown">剩余有效时间：{{ countdown }} 秒</div>
      </div>

      <div class="empty-box" v-else-if="!loading">
        正在获取付款码...
      </div>
    </div>

    <!-- 🚨 新增：底部消费记录卡片（完全还原截图） -->
    <div class="history-card">
      <div class="history-header">
        <div class="title">
          <van-icon name="balance-o" style="font-size: 18px;" /> 消费记录
        </div>
        <div class="more">查看更多 <van-icon name="arrow" /></div>
      </div>
      <div class="empty-history">
        <img src="https://b.yzcdn.cn/vant/empty-image-default.png" alt="" />
        <p>没有消费记录</p>
      </div>
    </div>

  </div>
</template>

<script>
import { getPayQrCode } from '@/api/service'

export default {
  data() {
    return {
      loading: true,
      brandId: '',
      shopId: '',
      brandName: '未命名品牌',
      shopName: '未命名门店',
      brandLogo: '',
      address: '',
      distance: '',

      payCode: '',
      validSeconds: 120,
      countdown: 120,
      timer: null,

      barcodeBars: []
    }
  },
  created() {
    const query = this.$route.query;
    this.brandId = query.brandId || '';
    this.shopId = query.shopId || '';
    this.brandName = query.brandName || '未命名品牌';
    this.shopName = query.shopName || '未命名门店';
    this.address = query.address || '暂无地址';
    this.distance = query.distance || '';
    this.brandLogo = query.logo || '';

    this.getCode();
  },
  beforeDestroy() {
    if (this.timer) clearInterval(this.timer);
  },
  methods: {
    getCode() {
      if (!this.brandId || !this.shopId) {
        this.$toast('缺少门店信息');
        this.loading = false;
        return;
      }

      this.loading = true;

      getPayQrCode({
        brandId: this.brandId,
        shopId: this.shopId
      }).then(res => {
        this.loading = false;
        if (res.code == 200 && res.data) {
          this.payCode = res.data.code;
          this.validSeconds = res.data.validSeconds || 120;

          this.generateBarcode(this.payCode);
          this.startCountdown();

          // 渲染本地二维码
          this.$nextTick(() => {
            this.drawCanvasQRCode(this.payCode);
          });

        } else {
          this.$toast(res.msg || '获取付款码失败');
        }
      }).catch(() => {
        this.loading = false;
        this.$toast('网络异常，请重试');
      });
    },

    // 弹窗显示数字大码
    showNumberCode() {
      if (!this.payCode) return;
      this.$dialog.alert({
        title: '付款数字码',
        message: `<div style="font-size: 24px; font-weight: bold; color: #333; letter-spacing: 2px; text-align: center; padding: 10px 0; word-break: break-all;">${this.payCode}</div>`,
        confirmButtonText: '我知道了',
        confirmButtonColor: '#F99E9B'
      });
    },

    // 生成本地 CSS 条形码
    generateBarcode(code) {
      let bars = [];
      for (let i = 0; i < code.length; i++) {
        let num = parseInt(code[i]);
        bars.push(num % 3 + 1);
        bars.push(num % 2 + 1);
        bars.push(num % 4 + 1);
      }
      this.barcodeBars = bars;
    },

    // 生成本地 Canvas 二维码（绝不依赖外网）
    drawCanvasQRCode(code) {
      const canvas = document.getElementById('qrCanvas');
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      const size = 160;
      const gridCount = 21;
      const cellSize = size / gridCount;

      // 清空白底
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, size, size);
      ctx.fillStyle = '#000000';

      // 画定位角（左上、右上、左下）
      const drawFinderPattern = (row, col) => {
        ctx.fillStyle = '#000000';
        ctx.fillRect(col * cellSize, row * cellSize, cellSize * 7, cellSize * 7);
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect((col + 1) * cellSize, (row + 1) * cellSize, cellSize * 5, cellSize * 5);
        ctx.fillStyle = '#000000';
        ctx.fillRect((col + 2) * cellSize, (row + 2) * cellSize, cellSize * 3, cellSize * 3);
      };

      drawFinderPattern(0, 0);
      drawFinderPattern(0, 14);
      drawFinderPattern(14, 0);

      // 根据 code 填充矩阵
      for (let r = 0; r < gridCount; r++) {
        for (let c = 0; c < gridCount; c++) {
          if ((r < 8 && c < 8) || (r < 8 && c > 12) || (r > 12 && c < 8)) continue;

          const charIndex = (r * gridCount + c) % code.length;
          const charCode = code.charCodeAt(charIndex);

          if ((charCode + r + c) % 2 === 0) {
            ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
          }
        }
      }
    },

    startCountdown() {
      if (this.timer) clearInterval(this.timer);
      this.countdown = this.validSeconds;

      this.timer = setInterval(() => {
        this.countdown--;
        if (this.countdown <= 0) {
          clearInterval(this.timer);
          this.getCode();
        }
      }, 1000);
    }
  }
}
</script>

<style scoped lang="less">
.pay-code-page {
  min-height: 100vh;
  background-color: #F99E9B;
  padding: 12px;
  box-sizing: border-box;
}

/* 顶部门店卡片 */
.store-card {
  background: #fff;
  border-radius: 12px;
  padding: 15px;
  margin-bottom: 12px;

  .store-header {
    display: flex;
    align-items: center;
    border-bottom: 1px solid #f5f5f5;
    padding-bottom: 12px;

    .store-logo {
      width: 60px;
      height: 60px;
      background: #F5F5F5;
      border-radius: 8px;
      margin-right: 15px;
      overflow: hidden;
      display: flex;
      justify-content: center;
      align-items: center;

      img {
        width: 80%;
        height: 80%;
        border-radius: 8px;
        object-fit: contain;
      }
    }

    .store-info {
      .row {
        font-size: 14px;
        color: #333;
        margin-bottom: 6px;
      }
    }
  }

  .store-current {
    margin-top: 12px;

    .current-title {
      font-size: 12px;
      color: #999;
      margin-bottom: 8px;
    }

    .current-address {
      display: flex;
      justify-content: space-between;
      align-items: center;

      .address-left {
        .title {
          font-size: 15px;
          font-weight: bold;
          color: #333;
        }

        .desc {
          font-size: 12px;
          color: #666;
          margin-top: 4px;
        }
      }

      .distance {
        font-size: 12px;
        color: #F99E9B;
      }
    }
  }
}

/* 提示条 */
.notice-bar {
  background: #ffffff;
  color: #F99E9B;
  font-size: 13px;
  padding: 10px 15px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 12px;
}

/* 付款码卡片 */
.pay-code-card {
  background: #fff;
  border-radius: 12px;
  padding: 15px;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 12px;
  // min-height: 480px;

  .card-title {
    align-self: flex-start;
    font-size: 15px;
    font-weight: bold;
    color: #333;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 20px;

    .icon-refresh {
      font-size: 18px;
      color: #F99E9B;
      cursor: pointer;
      transition: transform 0.3s;

      &:active {
        transform: rotate(180deg);
      }
    }
  }

  .code-container {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .barcode-box {
    width: 90%;
    height: 70px;
    background: #F8F8F8;
    border-radius: 8px;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 10px;
    box-sizing: border-box;
    overflow: hidden;
    cursor: pointer;

    .bar {
      height: 50px;
      background-color: #333;
      margin: 0 1px;
    }

    .bar:nth-child(even) {
      background-color: transparent;
    }
  }

  .tip-text {
    font-size: 12px;
    color: #F99E9B;
    margin: 15px 0;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .qrcode-box {
    width: 180px;
    height: 180px;
    background: #fff;
    border-radius: 8px;
    padding: 10px;
    box-sizing: border-box;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 15px;
    border: 1px solid #eee;
    cursor: pointer;
  }

  .countdown {
    font-size: 14px;
    color: #F99E9B;
    background: #FFF1F1;
    display: inline-block;
    padding: 4px 15px;
    border-radius: 20px;
  }

  .empty-box {
    color: #999;
    font-size: 14px;
    margin-top: 40px;
  }
}

/* 🚨 新增：消费记录卡片样式 */
.history-card {
  background: #fff;
  border-radius: 12px;
  padding: 15px;
  margin-bottom: 12px;

  .history-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #f5f5f5;
    padding-bottom: 12px;

    .title {
      font-size: 15px;
      font-weight: bold;
      color: #333;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .more {
      font-size: 12px;
      color: #999;
      display: flex;
      align-items: center;
      gap: 2px;
    }
  }

  .empty-history {
    text-align: center;
    padding: 40px 0 20px 0;

    img {
      width: 120px;
      opacity: 0.8;
    }

    p {
      font-size: 13px;
      color: #999;
      margin-top: 15px;
    }
  }
}
</style>